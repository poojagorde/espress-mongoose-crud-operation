var mongoose = require('mongoose');
var express = require('express');
var router = express.Router();

var StudentModel = require('./studentschema');

//Connecting to database
var query = 'mongodb://localhost:27017/test';

const db = (query);
mongoose.Promise = global.Promise;

mongoose.connect(db, { useNewUrlParser: true , useUnifiedTopology: true }, function(error) {
    if(error) {
        console.log("Error! " + error);
    }
})

module.exports = router;

router.get('/create', function(req, res) {
    
    var newStudent = new StudentModel({
        StudentId: 102, Name: "Sachin", Roll: 19, Address: "123"
    });

    newStudent.save(function(err, data) {
        if(err) {
            console.log(err);
        } else {
            res.send("Data Inserted" + data);
        }
    });

});

